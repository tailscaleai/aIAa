# KlapClone - Free AI Video Clipper

A completely free, open-source alternative to Klap.app. Designed to be deployed on Netlify.

## Features
- YouTube URL to Shorts logic
- Next.js 14 App Router
- Tailwind CSS styling
- Integrated with Cloudinary for AI cropping

## Setup
1. Clone the repo
2. Rename `.env.example` to `.env` and add your keys
3. `npm install`
4. `npm run dev`

## Deployment
Push to GitHub and connect to Netlify. The `netlify.toml` handles the configuration.
