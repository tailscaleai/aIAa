import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const { url } = await req.json();
  
  // 1. Extract YouTube ID
  // 2. Fetch metadata
  // 3. Trigger Serverless function for processing (ffmpeg/whisper)
  
  return NextResponse.json({ success: true, message: 'Processing started' });
}