import ClipCard from '@/components/clip-card';

const mockClips = [
  { id: '1', title: 'The Future of AI', status: 'Completed', thumbnail: 'https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg' },
  { id: '2', title: 'Coding Tips', status: 'Processing', thumbnail: '' },
];

export default function Dashboard() {
  return (
    <div className="max-w-7xl mx-auto p-6">
      <h2 className="text-3xl font-bold mb-8">My Clips</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {mockClips.map(clip => (
          <ClipCard key={clip.id} {...clip} />
        ))}
      </div>
    </div>
  );
}