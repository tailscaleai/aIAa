import VideoInput from '@/components/video-input';

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 text-center">
      <h1 className="text-5xl font-bold tracking-tight sm:text-7xl mb-6">
        Turn long videos into <span className="text-purple-500">viral clips</span>
      </h1>
      <p className="text-zinc-400 text-lg max-w-2xl mb-12">
        Paste a YouTube link and let AI do the rest. Extract the best moments, 
        crop to 9:16, and generate captions automatically. Free forever.
      </p>
      <VideoInput />
    </div>
  );
}