import Link from 'next/link';
import { PlayCircle, Clock } from 'lucide-react';

export default function ClipCard({ id, title, status, thumbnail }: any) {
  return (
    <Link href={`/clip/${id}`} className="group bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden hover:border-purple-500/50 transition">
      <div className="aspect-video bg-zinc-800 relative">
        {thumbnail ? <img src={thumbnail} alt={title} className="w-full h-full object-cover" /> : (
          <div className="flex items-center justify-center h-full"><Clock className="text-zinc-500" /></div>
        )}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
          <PlayCircle className="w-12 h-12 text-white" />
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-semibold mb-1">{title}</h3>
        <span className={`text-xs px-2 py-0.5 rounded-full ${status === 'Completed' ? 'bg-green-500/10 text-green-500' : 'bg-yellow-500/10 text-yellow-500'}`}>
          {status}
        </span>
      </div>
    </Link>
  );
}