import Link from 'next/link';
import { Video } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between p-6 max-w-7xl mx-auto">
      <Link href="/" className="flex items-center gap-2 font-bold text-xl">
        <Video className="w-6 h-6 text-purple-500" />
        <span>KlapFree</span>
      </Link>
      <div className="flex gap-6">
        <Link href="/dashboard" className="text-sm hover:text-purple-400 transition">Dashboard</Link>
      </div>
    </nav>
  );
}