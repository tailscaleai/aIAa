'use client';
import { useState } from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function VideoInput() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      router.push('/dashboard');
    }, 1500);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-xl relative">
      <input
        type="text"
        placeholder="Paste YouTube URL here..."
        className="w-full bg-zinc-900 border border-zinc-800 rounded-full py-4 px-6 pr-32 focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        required
      />
      <button
        type="submit"
        disabled={loading}
        className="absolute right-2 top-2 bottom-2 bg-purple-600 hover:bg-purple-700 text-white px-6 rounded-full flex items-center gap-2 font-medium transition disabled:opacity-50"
      >
        {loading ? 'Processing...' : (
          <>
            Gen Clips <Sparkles className="w-4 h-4" />
          </>
        )}
      </button>
    </form>
  );
}