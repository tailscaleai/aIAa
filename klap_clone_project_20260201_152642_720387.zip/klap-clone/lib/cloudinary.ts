// Integration with Cloudinary for video hosting and transformation
export const generateVideoUrl = (publicId: string, format: '9:16' | '1:1') => {
  const crop = format === '9:16' ? 'ar_9:16,c_fill,g_auto' : 'ar_1:1,c_fill,g_auto';
  return `https://res.cloudinary.com/${process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME}/video/upload/${crop}/${publicId}.mp4`;
};