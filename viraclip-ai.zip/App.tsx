
import React, { useState, useRef, useEffect } from 'react';
import Navbar from './components/Navbar';
import ClipCard from './components/ClipCard';
import EditorModal from './components/EditorModal';
import VideoPreview from './components/VideoPreview';
import { analyzeVideoForHighlights, analyzeUrlForHighlights, generateViralPoster } from './services/geminiService';
import { VideoClip, ProcessingState, UserProject } from './types';

// The global declaration for aistudio is removed because it is pre-configured and accessible in the environment.
// Redefining it can cause modifier mismatch errors with existing declarations.

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'upload' | 'url'>('url');
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [isApiKeySelected, setIsApiKeySelected] = useState<boolean | null>(null);
  const [processingState, setProcessingState] = useState<ProcessingState>({
    status: 'idle',
    progress: 0,
    message: ''
  });
  const [currentProject, setCurrentProject] = useState<UserProject | null>(null);
  const [editingClip, setEditingClip] = useState<VideoClip | null>(null);
  const [previewingClip, setPreviewingClip] = useState<VideoClip | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const checkKey = async () => {
      // Accessing aistudio assuming it is pre-configured globally as per guidelines.
      const aistudio = (window as any).aistudio;
      if (aistudio && typeof aistudio.hasSelectedApiKey === 'function') {
        const hasKey = await aistudio.hasSelectedApiKey();
        setIsApiKeySelected(hasKey);
      } else {
        setIsApiKeySelected(true);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio && typeof aistudio.openSelectKey === 'function') {
      await aistudio.openSelectKey();
      // Guidance: assume success after triggering the selection dialog to avoid race conditions.
      setIsApiKeySelected(true);
    }
  };

  const extractThumbnail = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => video.currentTime = 1;
      video.onseeked = () => {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.6));
      };
      video.src = URL.createObjectURL(file);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setProcessingState({ status: 'uploading', progress: 15, message: 'Processing local file...' });
    try {
      const thumbnail = await extractThumbnail(file);
      const videoUrl = URL.createObjectURL(file);
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        setProcessingState({ status: 'analyzing', progress: 45, message: 'Gemini AI is scanning content...' });
        try {
          const clips = await analyzeVideoForHighlights(base64Data, file.name);
          setCurrentProject({
            id: `f-${Date.now()}`,
            originalVideoName: file.name,
            originalVideoSize: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
            date: new Date().toLocaleDateString(),
            clips: clips.map(c => ({ ...c, thumbnailUrl: thumbnail })),
            sources: [],
            videoUrl
          });
          setProcessingState({ status: 'completed', progress: 100, message: 'Analysis Complete' });
        } catch (err: any) {
          // Reset key state if unauthorized/not found as per guidelines to prompt re-selection.
          if (err?.message?.includes("entity was not found")) setIsApiKeySelected(false);
          setProcessingState({ status: 'error', progress: 0, message: 'AI Analysis Failed' });
        }
      };
    } catch (err) {
      setProcessingState({ status: 'error', progress: 0, message: 'File Error' });
    }
  };

  const handleUrlProcess = async () => {
    if (!youtubeUrl) return;
    setProcessingState({ status: 'uploading', progress: 20, message: 'Researching Web Source...' });
    try {
      const { clips, sources } = await analyzeUrlForHighlights(youtubeUrl);
      setCurrentProject({
        id: `y-${Date.now()}`,
        originalVideoName: youtubeUrl,
        originalVideoSize: 'Cloud Stream',
        date: new Date().toLocaleDateString(),
        clips,
        sources
      });
      setProcessingState({ status: 'completed', progress: 100, message: 'Web Analysis Complete' });
    } catch (err: any) {
      if (err?.message?.includes("entity was not found")) setIsApiKeySelected(false);
      setProcessingState({ status: 'error', progress: 0, message: 'Research Failed' });
    }
  };

  const updateClip = (updatedClip: VideoClip) => {
    if (!currentProject) return;
    const updatedClips = currentProject.clips.map(c => c.id === updatedClip.id ? updatedClip : c);
    setCurrentProject({ ...currentProject, clips: updatedClips });
    setEditingClip(null);
  };

  const handleMagicExport = async (clip: VideoClip) => {
    setProcessingState({ status: 'exporting', progress: 0, message: 'Pre-flight check...' });
    const steps = [
      { p: 30, m: 'Re-framing to 9:16 vertical...' },
      { p: 60, m: 'Rendering AI Captions...' },
      { p: 90, m: 'Optimizing for mobile feed...' }
    ];
    for (const step of steps) {
      await new Promise(r => setTimeout(r, 1000));
      setProcessingState(prev => ({ ...prev, progress: step.p, message: step.m }));
    }
    setProcessingState({ status: 'completed', progress: 100, message: 'Export Ready' });
    alert(`"${clip.title}" is ready for download.`);
  };

  if (isApiKeySelected === false) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-[#030014]">
        <div className="glass-card max-w-lg w-full p-12 rounded-[2rem] text-center space-y-8 animate-in fade-in zoom-in-95 duration-700">
          <div className="w-24 h-24 bg-purple-600 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-purple-500/20 float-animation">
             <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="white" viewBox="0 0 256 256"><path d="M208,128a80,80,0,1,1-80-80A80,80,0,0,1,208,128Z" opacity="0.2"></path><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216ZM140,128a12,12,0,1,1-12-12A12,12,0,0,1,140,128Z"></path></svg>
          </div>
          <div className="space-y-4">
            <h1 className="text-4xl font-black tracking-tight">AI Engine Locked</h1>
            <p className="text-gray-400 leading-relaxed text-lg">ViraClip AI utilizes advanced Gemini models that require a premium API key for heavy lifting.</p>
          </div>
          <div className="space-y-4 pt-4">
            <button onClick={handleSelectKey} className="w-full h-16 bg-white text-black font-black text-xl rounded-2xl hover:bg-gray-200 transition-all hover:scale-[1.02] active:scale-95 shadow-2xl">Connect Engine</button>
            <p className="text-sm text-gray-500">Need a key? <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-purple-400 font-bold hover:underline">Setup billing here</a></p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 overflow-x-hidden">
      <Navbar />
      <div className="hero-glow top-[-200px] left-[-200px]"></div>
      <div className="hero-glow bottom-[-200px] right-[-200px] opacity-50"></div>

      <main className="container mx-auto px-6 pt-32">
        {processingState.status === 'idle' && !currentProject && (
          <div className="max-w-4xl mx-auto text-center space-y-10 animate-in fade-in slide-in-from-bottom-12 duration-1000">
            <div className="inline-block px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full text-purple-400 text-sm font-bold tracking-widest uppercase mb-4">Powered by Gemini AI</div>
            <h1 className="text-7xl md:text-9xl font-black tracking-tighter leading-none">
              GO VIRAL <br/><span className="gradient-text">FASTER</span>
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">The only AI repurposing studio designed for the high-retention era.</p>
            
            <div className="pt-12 space-y-8">
              <div className="max-w-md mx-auto glass-card rounded-2xl p-1.5 flex shadow-2xl">
                <button onClick={() => setActiveTab('url')} className={`flex-1 py-4 rounded-xl font-black transition-all ${activeTab === 'url' ? 'bg-purple-600 shadow-xl shadow-purple-500/30' : 'text-gray-500 hover:text-white'}`}>LINK</button>
                <button onClick={() => setActiveTab('upload')} className={`flex-1 py-4 rounded-xl font-black transition-all ${activeTab === 'upload' ? 'bg-purple-600 shadow-xl shadow-purple-500/30' : 'text-gray-500 hover:text-white'}`}>UPLOAD</button>
              </div>
              
              {activeTab === 'url' ? (
                <div className="max-w-2xl mx-auto flex flex-col md:flex-row gap-4 p-2 glass-card rounded-[2rem]">
                  <input placeholder="Paste long-form video URL..." className="flex-1 h-16 bg-transparent rounded-2xl px-8 focus:outline-none text-lg" value={youtubeUrl} onChange={(e) => setYoutubeUrl(e.target.value)} />
                  <button onClick={handleUrlProcess} className="h-16 px-12 bg-white text-black font-black rounded-2xl hover:bg-gray-200 transition-all text-lg shadow-xl">Analyze</button>
                </div>
              ) : (
                <div onClick={() => fileInputRef.current?.click()} className="max-w-2xl mx-auto glass-card border-dashed border-2 border-white/20 rounded-[3rem] p-24 cursor-pointer hover:bg-white/5 transition-all group">
                  <div className="space-y-4">
                    <div className="w-16 h-16 bg-purple-500/20 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                       <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="text-purple-400" viewBox="0 0 256 256"><path d="M208,80H172V44a12,12,0,0,0-24,0V80H112a12,12,0,0,0,0,24h36v36a12,12,0,0,0,24,0V104h36a12,12,0,0,0,0-24Z" opacity="0.2"></path><path d="M216,76H180V40a8,8,0,0,0-16,0V76H128a8,8,0,0,0,0,16h36v36a8,8,0,0,0,16,0V92h36a8,8,0,0,0,0-16Z"></path></svg>
                    </div>
                    <p className="font-black text-2xl">Drop raw footage</p>
                    <p className="text-gray-500 font-medium">MP4, MOV, or WEBM up to 2GB</p>
                  </div>
                  <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="video/*" />
                </div>
              )}
            </div>
          </div>
        )}

        {(processingState.status !== 'idle' && processingState.status !== 'completed' && !currentProject) && (
          <div className="max-w-2xl mx-auto pt-32 flex flex-col items-center gap-12 text-center">
            <div className="relative">
              <div className="w-48 h-48 border-[12px] border-purple-500/10 rounded-full shadow-[0_0_80px_rgba(168,85,247,0.1)]"></div>
              <div className="absolute inset-0 border-[12px] border-purple-500 rounded-full border-t-transparent animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center font-black text-4xl text-purple-400">{processingState.progress}%</div>
            </div>
            <div className="space-y-4">
              <h2 className="text-5xl font-black tracking-tight">{processingState.message}</h2>
              <p className="text-gray-400 font-medium text-lg">Our neural network is identifying retention hooks...</p>
            </div>
          </div>
        )}

        {currentProject && (
          <div className="space-y-16 animate-in fade-in slide-in-from-bottom-12 duration-1000">
            <header className="flex flex-col lg:flex-row lg:items-end justify-between border-b border-white/10 pb-12 gap-10">
              <div className="space-y-6">
                <button onClick={() => { setCurrentProject(null); setProcessingState({ status: 'idle', progress: 0, message: '' }); }} className="text-gray-500 hover:text-white flex items-center gap-2 text-sm font-black transition-colors">← NEW DASHBOARD</button>
                <div className="space-y-2">
                  <h1 className="text-6xl font-black tracking-tighter">Highlights</h1>
                  <p className="text-gray-400 font-mono text-xs uppercase tracking-widest">{currentProject.originalVideoName}</p>
                </div>
              </div>

              {currentProject.sources && currentProject.sources.length > 0 && (
                <div className="flex-1 max-w-xl">
                  <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-4">Search Grounded Intelligence</p>
                  <div className="flex flex-wrap gap-2">
                    {currentProject.sources.map((s, i) => (
                      <a key={i} href={s.uri} target="_blank" className="text-[11px] bg-white/5 border border-white/10 px-4 py-2 rounded-xl hover:bg-purple-500/20 hover:border-purple-500 transition-all flex items-center gap-3">
                        <span className="w-2 h-2 bg-green-500 rounded-full shadow-[0_0_12px_rgba(34,197,94,0.8)]"></span>
                        {s.title}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
              {currentProject.clips.map(clip => (
                <ClipCard 
                  key={clip.id}
                  clip={clip} 
                  onEdit={setEditingClip}
                  onExport={handleMagicExport}
                  onPlay={() => currentProject.videoUrl && setPreviewingClip(clip)} 
                />
              ))}
            </div>
          </div>
        )}
      </main>

      {editingClip && <EditorModal clip={editingClip} onClose={() => setEditingClip(null)} onSave={updateClip} />}
      {previewingClip && currentProject?.videoUrl && (
        <VideoPreview videoUrl={currentProject.videoUrl} clip={previewingClip} onClose={() => setPreviewingClip(null)} />
      )}
    </div>
  );
};

export default App;
