
import React from 'react';
import { VideoClip } from '../types';

interface ClipCardProps {
  clip: VideoClip;
  onExport: (clip: VideoClip) => void;
  onEdit: (clip: VideoClip) => void;
  onPlay: () => void;
}

const ClipCard: React.FC<ClipCardProps> = ({ clip, onExport, onEdit, onPlay }) => {
  const thumbUrl = clip.thumbnailUrl || `https://picsum.photos/seed/${clip.id}/400/700`;

  return (
    <div className="glass-card rounded-[2rem] overflow-hidden group hover:border-purple-500/40 transition-all duration-500 shadow-2xl flex flex-col">
      <div className="relative aspect-[9/16] bg-gray-950 overflow-hidden cursor-pointer" onClick={onPlay}>
        <img 
          src={thumbUrl} 
          alt={clip.title}
          className="w-full h-full object-cover opacity-60 group-hover:scale-110 group-hover:opacity-100 transition-all duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
        
        <div className="absolute top-6 left-6 flex flex-col gap-3">
          <div className="bg-purple-600 text-white text-[11px] font-black px-3 py-1.5 rounded-lg shadow-2xl uppercase tracking-widest flex items-center gap-2">
             <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
            {clip.viralScore}% VIRAL
          </div>
          <div className="bg-black/80 backdrop-blur-xl text-white text-[10px] font-bold px-3 py-1.5 rounded-lg border border-white/10 tracking-widest">
            {clip.startTime} — {clip.endTime}
          </div>
        </div>
        
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500">
          <div className="w-20 h-20 bg-white/20 backdrop-blur-2xl rounded-full flex items-center justify-center text-white border border-white/30 scale-90 group-hover:scale-100 transition-transform">
             <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="white" viewBox="0 0 256 256"><path d="M240,128a15.74,15.74,0,0,1-7.6,13.51L88.32,229.75a16,16,0,0,1-24.32-13.75V40a16,16,0,0,1,24.32-13.75l144.08,88.24A15.74,15.74,0,0,1,240,128Z"></path></svg>
          </div>
        </div>
      </div>

      <div className="p-8 space-y-6 flex-1 flex flex-col">
        <div className="space-y-1">
          <h3 className="font-black text-xl leading-tight truncate group-hover:text-purple-400 transition-colors uppercase tracking-tight">{clip.title}</h3>
          <p className="text-[10px] text-gray-500 font-black uppercase tracking-[0.2em]">{clip.duration}s RE-FRAME</p>
        </div>
        
        <p className="text-sm text-gray-400 line-clamp-2 font-medium leading-relaxed italic opacity-70 flex-1">
          "{clip.suggestedCaption}"
        </p>

        <div className="flex gap-3 pt-2">
          <button 
            onClick={(e) => { e.stopPropagation(); onEdit(clip); }}
            className="flex-1 h-14 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all"
          >
            EDIT
          </button>
          <button 
            onClick={(e) => { e.stopPropagation(); onExport(clip); }}
            className="flex-[2] h-14 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-xl shadow-purple-500/20 transition-all active:scale-95"
          >
            MAGIC EXPORT
          </button>
        </div>
      </div>
    </div>
  );
};

export default ClipCard;
