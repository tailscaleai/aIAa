
import React, { useState } from 'react';
import { VideoClip } from '../types';

interface EditorModalProps {
  clip: VideoClip;
  onClose: () => void;
  onSave: (updatedClip: VideoClip) => void;
}

const EditorModal: React.FC<EditorModalProps> = ({ clip, onClose, onSave }) => {
  const [editedClip, setEditedClip] = useState(clip);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/90 backdrop-blur-2xl">
      <div className="glass-card w-full max-w-2xl rounded-[3rem] overflow-hidden animate-in zoom-in-95 duration-500 shadow-[0_0_100px_rgba(168,85,247,0.1)]">
        <div className="p-10 border-b border-white/10 flex justify-between items-center">
          <h2 className="text-3xl font-black tracking-tighter uppercase">Refine Metadata</h2>
          <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all">
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 256 256"><path d="M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z"></path></svg>
          </button>
        </div>
        <div className="p-10 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <label className="text-xs font-black text-gray-500 uppercase tracking-widest">Title</label>
              <input 
                value={editedClip.title} 
                onChange={(e) => setEditedClip({...editedClip, title: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-lg font-bold focus:border-purple-500 outline-none transition-all"
              />
            </div>
            <div className="space-y-4">
              <label className="text-xs font-black text-gray-500 uppercase tracking-widest">Viral Potential</label>
              <input 
                type="number"
                value={editedClip.viralScore} 
                onChange={(e) => setEditedClip({...editedClip, viralScore: Number(e.target.value)})}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-lg font-bold focus:border-purple-500 outline-none transition-all"
              />
            </div>
          </div>
          <div className="space-y-4">
            <label className="text-xs font-black text-gray-500 uppercase tracking-widest">Social Hook Caption</label>
            <textarea 
              rows={4}
              value={editedClip.suggestedCaption} 
              onChange={(e) => setEditedClip({...editedClip, suggestedCaption: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-3xl px-6 py-6 text-lg font-medium focus:border-purple-500 outline-none resize-none transition-all leading-relaxed"
            />
          </div>
        </div>
        <div className="p-10 bg-white/5 flex justify-end gap-6">
          <button onClick={onClose} className="px-10 py-4 rounded-2xl text-sm font-black uppercase tracking-widest text-gray-500 hover:text-white transition-all">Discard</button>
          <button 
            onClick={() => onSave(editedClip)}
            className="px-12 py-4 rounded-2xl text-sm font-black uppercase tracking-widest bg-purple-600 hover:bg-purple-700 transition-all shadow-xl shadow-purple-500/20"
          >
            Apply Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditorModal;
