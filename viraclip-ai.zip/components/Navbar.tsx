
import React from 'react';

const Navbar: React.FC = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-8 py-6 flex items-center justify-between glass-card border-none bg-black/50 backdrop-blur-2xl">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center font-black text-2xl text-white shadow-xl shadow-purple-500/20">V</div>
        <span className="text-2xl font-black tracking-tighter">ViraClip <span className="text-purple-500">AI</span></span>
      </div>
      <div className="hidden lg:flex items-center gap-10 text-xs font-black uppercase tracking-widest text-gray-400">
        <a href="#" className="hover:text-white transition-colors">Neural Hub</a>
        <a href="#" className="hover:text-white transition-colors">Pricing</a>
        <a href="#" className="hover:text-white transition-colors">Community</a>
      </div>
      <div className="flex items-center gap-4">
        <button className="hidden sm:block px-6 py-2 text-xs font-black uppercase tracking-widest text-gray-300 hover:text-white transition-colors">Login</button>
        <button className="px-8 py-3 text-xs font-black uppercase tracking-widest bg-white text-black rounded-xl hover:bg-gray-200 transition-all shadow-xl">Start Free</button>
      </div>
    </nav>
  );
};

export default Navbar;
