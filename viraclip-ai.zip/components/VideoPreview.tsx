
import React, { useRef, useEffect, useState } from 'react';
import { VideoClip } from '../types';

interface VideoPreviewProps {
  videoUrl: string;
  clip: VideoClip;
  onClose: () => void;
}

const VideoPreview: React.FC<VideoPreviewProps> = ({ videoUrl, clip, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const parseTimeToSeconds = (timeStr: string) => {
    const parts = timeStr.split(':').map(Number);
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return parts[0] || 0;
  };

  const startSec = parseTimeToSeconds(clip.startTime);
  const endSec = parseTimeToSeconds(clip.endTime);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = startSec;
      const checkTime = () => {
        if (videoRef.current && videoRef.current.currentTime >= endSec) {
          videoRef.current.pause();
          videoRef.current.currentTime = startSec;
          setIsPlaying(false);
        }
      };
      videoRef.current.addEventListener('timeupdate', checkTime);
      return () => videoRef.current?.removeEventListener('timeupdate', checkTime);
    }
  }, [startSec, endSec]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/95 backdrop-blur-3xl animate-in fade-in duration-500">
      <div className="relative w-full max-w-[420px] aspect-[9/16] bg-black rounded-[3rem] overflow-hidden shadow-[0_0_120px_rgba(0,0,0,0.8)] border border-white/10 flex flex-col">
        <div className="absolute top-0 left-0 right-0 p-8 bg-gradient-to-b from-black/90 to-transparent z-10 flex justify-between items-start">
           <div className="space-y-1">
              <p className="text-[10px] font-black text-purple-400 uppercase tracking-[0.3em]">NEURAL PREVIEW</p>
              <h2 className="text-xl font-black truncate pr-6 tracking-tight uppercase">{clip.title}</h2>
           </div>
           <button onClick={onClose} className="p-3 bg-white/10 hover:bg-white/20 rounded-2xl transition-all">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 256 256"><path d="M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z"></path></svg>
           </button>
        </div>

        <video 
          ref={videoRef}
          src={videoUrl}
          className="w-full h-full object-cover"
          playsInline
        />

        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
           {!isPlaying && (
              <button onClick={(e) => { e.stopPropagation(); togglePlay(); }} className="w-24 h-24 bg-white/20 backdrop-blur-3xl rounded-full flex items-center justify-center text-white pointer-events-auto hover:scale-110 transition-all border border-white/20 shadow-2xl">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="white" viewBox="0 0 256 256"><path d="M240,128a15.74,15.74,0,0,1-7.6,13.51L88.32,229.75a16,16,0,0,1-24.32-13.75V40a16,16,0,0,1,24.32-13.75l144.08,88.24A15.74,15.74,0,0,1,240,128Z"></path></svg>
              </button>
           )}
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-10 bg-gradient-to-t from-black via-black/80 to-transparent">
           <div className="space-y-6">
              <p className="text-sm text-gray-300 leading-relaxed italic font-medium opacity-80">"{clip.suggestedCaption}"</p>
              <div className="flex items-center gap-4">
                 <div className="h-1.5 flex-1 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.8)]" style={{ width: '60%' }}></div>
                 </div>
                 <span className="text-xs font-black font-mono text-gray-400">{clip.startTime} — {clip.endTime}</span>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPreview;
