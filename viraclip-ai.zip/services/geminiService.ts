
import { GoogleGenAI, Type } from "@google/genai";
import { VideoClip, GroundingSource } from "../types";

export const analyzeVideoForHighlights = async (
  videoBase64: string,
  fileName: string
): Promise<VideoClip[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    Analyze this video file "${fileName}" and identify 3-5 high-potential viral segments.
    For each segment, provide:
    1. Catchy title
    2. Start and end timestamps (MM:SS)
    3. Estimated viral score (0-100)
    4. Reasoning based on psychological triggers
    5. A viral caption for social media.
    Return the data as a clean JSON array.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: {
        parts: [
          { inlineData: { data: videoBase64, mimeType: "video/mp4" } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              startTime: { type: Type.STRING },
              endTime: { type: Type.STRING },
              duration: { type: Type.STRING },
              viralScore: { type: Type.NUMBER },
              reason: { type: Type.STRING },
              suggestedCaption: { type: Type.STRING }
            },
            required: ["title", "startTime", "endTime", "viralScore", "reason", "suggestedCaption"]
          }
        },
        thinkingConfig: { thinkingBudget: 12000 }
      }
    });

    const parsed = JSON.parse(response.text || "[]");
    return parsed.map((clip: any, index: number) => ({
      ...clip,
      id: `file-${Date.now()}-${index}`
    }));
  } catch (error) {
    console.error("Gemini Video Analysis Error:", error);
    throw error;
  }
};

export const analyzeUrlForHighlights = async (url: string): Promise<{ clips: VideoClip[], sources: GroundingSource[] }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    Conduct deep research on the video content located at: ${url}.
    Identify 3-5 segments with high virality potential for TikTok/Reels.
    Include titles, timestamps, and emotional hooks.
    Format your response with a JSON array clearly marked.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 16000 }
      }
    });

    const text = response.text || "";
    let clips: VideoClip[] = [];
    const jsonMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (jsonMatch) {
      try {
        clips = JSON.parse(jsonMatch[0]);
      } catch (e) { console.warn("JSON Parse Failed", e); }
    }

    const sources: GroundingSource[] = [];
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    if (groundingMetadata?.groundingChunks) {
      groundingMetadata.groundingChunks.forEach((chunk: any) => {
        if (chunk.web?.uri) {
          sources.push({ title: chunk.web.title || "Reference", uri: chunk.web.uri });
        }
      });
    }

    return { 
      clips: clips.map((c, i) => ({ ...c, id: `url-${Date.now()}-${i}` })), 
      sources: Array.from(new Map(sources.map(s => [s.uri, s])).values())
    };
  } catch (error) {
    console.error("Gemini URL Analysis Error:", error);
    throw error;
  }
};

export const generateViralPoster = async (clip: VideoClip): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Hyper-realistic, cinematic YouTube thumbnail for: "${clip.title}". 
  Subject: ${clip.reason}. 
  Style: Epic lighting, high contrast, 9:16 vertical ratio. NO TEXT. Pure visual storytelling.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: { imageConfig: { aspectRatio: "9:16" } },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return "";
  } catch (error) {
    console.error("Poster Error:", error);
    return "";
  }
};
