
export interface VideoClip {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  duration: string;
  viralScore: number;
  reason: string;
  suggestedCaption: string;
  thumbnailUrl?: string;
  posterUrl?: string;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ProcessingState {
  status: 'idle' | 'uploading' | 'analyzing' | 'completed' | 'error' | 'exporting';
  progress: number;
  message: string;
}

export interface UserProject {
  id: string;
  originalVideoName: string;
  originalVideoSize: string;
  date: string;
  clips: VideoClip[];
  sources?: GroundingSource[];
  videoUrl?: string;
}
